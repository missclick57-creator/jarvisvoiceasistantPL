/* ============================================================
   J.A.R.V.I.S. — Arc Reactor Canvas Animation Engine
   ============================================================
   Renderuje reaktor Arc z obracającymi się pierścieniami,
   geometrycznym rdzeniem (ikosaedr) i panelami informacyjnymi.
   ============================================================ */

// ---- Canvas Setup ----
const canvas = document.getElementById('reactor');
const ctx = canvas.getContext('2d');
let W, H, cx, cy, R; // width, height, center, base radius

function resize() {
    const dpr = window.devicePixelRatio || 1;
    W = canvas.width = window.innerWidth * dpr;
    H = canvas.height = window.innerHeight * dpr;
    canvas.style.width = window.innerWidth + 'px';
    canvas.style.height = window.innerHeight + 'px';
    ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
    cx = window.innerWidth / 2;
    cy = window.innerHeight / 2;
    R = Math.min(window.innerWidth, window.innerHeight) * 0.32;
}
window.addEventListener('resize', resize);
resize();

// ---- State ----
let currentState = 'idle';     // idle | listening | speaking
let speakIntensity = 0;        // 0-1, smoothly transitions
let audioLevel = 0;            // 0-1, real-time audio amplitude from TTS playback
let smoothAudioLevel = 0;      // wygładzony poziom audio (do animacji)
let listenBreath = 0;          // faza oddychania w trybie nasłuchu
let time = 0;
const logs = [];
let stats = {};

// ---- Icosahedron Geometry (for core) ----
const PHI = (1 + Math.sqrt(5)) / 2;
const icoVertices = [
    [0, 1, PHI], [0, -1, PHI], [0, 1, -PHI], [0, -1, -PHI],
    [1, PHI, 0], [-1, PHI, 0], [1, -PHI, 0], [-1, -PHI, 0],
    [PHI, 0, 1], [-PHI, 0, 1], [PHI, 0, -1], [-PHI, 0, -1]
].map(v => {
    const len = Math.sqrt(v[0]*v[0] + v[1]*v[1] + v[2]*v[2]);
    return [v[0]/len, v[1]/len, v[2]/len]; // normalize
});

const icoEdges = [
    [0,1],[0,4],[0,5],[0,8],[0,9],
    [1,6],[1,7],[1,8],[1,9],
    [2,3],[2,4],[2,5],[2,10],[2,11],
    [3,6],[3,7],[3,10],[3,11],
    [4,5],[4,8],[4,10],
    [5,9],[5,11],
    [6,7],[6,8],[6,10],
    [7,9],[7,11],
    [8,10],[9,11]
];

// ---- Ring Definitions (Stark Holographic Gold/Orange Theme) ----
const rings = [
    // outer glow ring
    { r: 1.00, w: 18, spd: 0.08, col: '#ff9800', glow: 35, op: 0.75, segs: 1,  gap: 0 },
    // segmented outer orbital
    { r: 0.91, w: 2.5,spd:-0.15, col: '#ff6d00', glow: 12, op: 0.55, segs: 72, gap: 0.25 },
    // gold markers ring
    { r: 0.84, w: 9,  spd: 0.06, col: '#ffab00', glow: 15, op: 0.70, segs: 24, gap: 0.35, markers: true, mCol: '#ffe082' },
    // thin amber ring
    { r: 0.76, w: 1.5,spd:-0.22, col: '#ffa726', glow: 8,  op: 0.40, segs: 48, gap: 0.20 },
    // orange segments with bright gold markers
    { r: 0.69, w: 7,  spd: 0.10, col: '#ff5722', glow: 14, op: 0.60, segs: 16, gap: 0.40, markers: true, mCol: '#ffcc80' },
    // thin inner amber
    { r: 0.60, w: 1.2,spd:-0.28, col: '#ff9800', glow: 6,  op: 0.35, segs: 36, gap: 0.20 },
    // inner gold ring
    { r: 0.53, w: 5,  spd: 0.18, col: '#ffab00', glow: 10, op: 0.55, segs: 20, gap: 0.30, markers: true, mCol: '#ffe082' },
    // innermost ring
    { r: 0.45, w: 2,  spd:-0.14, col: '#ff8f00', glow: 12, op: 0.45, segs: 1,  gap: 0 },
];

// ---- 3D Rotation Helpers ----
function rotateY(v, angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    return [c*v[0] + s*v[2], v[1], -s*v[0] + c*v[2]];
}
function rotateX(v, angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    return [v[0], c*v[1] - s*v[2], s*v[1] + c*v[2]];
}
function rotateZ(v, angle) {
    const c = Math.cos(angle), s = Math.sin(angle);
    return [c*v[0] - s*v[1], s*v[0] + c*v[1], v[2]];
}
function project(v, scale) {
    const perspective = 3.5;
    const factor = perspective / (perspective + v[2]);
    return [v[0] * scale * factor, v[1] * scale * factor];
}

// ============================================================
// DRAWING FUNCTIONS
// ============================================================

function drawBackground() {
    // Czarno-szare eleganckie tło z subtelnym bursztynowym blaskiem w centrum
    const grad = ctx.createRadialGradient(cx, cy, 0, cx, cy, Math.max(cx, cy) * 1.2);
    grad.addColorStop(0, '#161310');   // Ciemny grafitowy bursztyn
    grad.addColorStop(0.45, '#0a0908'); // Onyksowy czarny
    grad.addColorStop(1, '#020202');   // Głęboka czerń
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, window.innerWidth, window.innerHeight);
}

function drawCentralGlow() {
    // Ciepła złotawo-pomarańczowa poświata centralna reagująca na głos
    const speakGlow = speakIntensity * (0.10 + smoothAudioLevel * 0.35);
    const idleGlow = (1 - speakIntensity) * 0.03 * Math.sin(time * 1.2);
    const pulse = 1 + speakGlow + idleGlow;
    const glowR = R * 0.55 * pulse;

    const g1 = ctx.createRadialGradient(cx, cy, 0, cx, cy, glowR);
    const glowAlpha = 0.25 + smoothAudioLevel * 0.30;
    g1.addColorStop(0, `rgba(255,152,0,${glowAlpha})`);
    g1.addColorStop(0.4, `rgba(255,109,0,${glowAlpha * 0.35})`);
    g1.addColorStop(1, 'rgba(255,152,0,0)');
    ctx.fillStyle = g1;
    ctx.fillRect(0, 0, window.innerWidth, window.innerHeight);
}

function drawRing(ring) {
    const radius = R * ring.r;
    const rotation = time * ring.spd;
    const speedBoost = 1 + speakIntensity * 0.3;

    ctx.save();
    ctx.translate(cx, cy);
    ctx.rotate(rotation * speedBoost);

    ctx.shadowColor = ring.col;
    ctx.shadowBlur = ring.glow * (1 + speakIntensity * 0.4);
    ctx.globalAlpha = ring.op;
    ctx.strokeStyle = ring.col;
    ctx.lineWidth = ring.w;
    ctx.lineCap = 'butt';

    if (ring.segs <= 1) {
        ctx.beginPath();
        ctx.arc(0, 0, radius, 0, Math.PI * 2);
        ctx.stroke();
    } else {
        const segAngle = (Math.PI * 2) / ring.segs;
        const gapAngle = segAngle * ring.gap;

        for (let i = 0; i < ring.segs; i++) {
            const start = i * segAngle + gapAngle / 2;
            const end = (i + 1) * segAngle - gapAngle / 2;

            ctx.beginPath();
            ctx.arc(0, 0, radius, start, end);
            ctx.stroke();

            if (ring.markers && i % 2 === 0) {
                const midAngle = (start + end) / 2;
                const mx = Math.cos(midAngle) * radius;
                const my = Math.sin(midAngle) * radius;
                ctx.save();
                ctx.shadowBlur = ring.glow * 0.6;
                ctx.shadowColor = ring.mCol || ring.col;
                ctx.fillStyle = ring.mCol || ring.col;
                ctx.globalAlpha = ring.op * 0.9;

                ctx.translate(mx, my);
                ctx.rotate(midAngle);
                ctx.fillRect(-5, -ring.w * 0.4, 10, ring.w * 0.8);
                ctx.restore();
            }
        }
    }
    ctx.restore();
}

function drawCore() {
    // === Rozmiar pomarańczowej kuli holograficznej Starka reaguje na stan ===
    const speakPulse = speakIntensity * (0.18 + smoothAudioLevel * 0.65);
    const listenShrink = currentState === 'listening' ? -0.15 + 0.05 * Math.sin(listenBreath) : 0;
    const idleBreath = (1 - speakIntensity) * 0.03 * Math.sin(time * 0.8);
    const pulse = 1 + speakPulse + listenShrink + idleBreath;
    const sphereR = R * 0.32 * pulse;

    // Obroty trójwymiarowej sfery w przestrzeni 3D
    const baseSpeed = currentState === 'listening' ? 0.25 : 0.6;
    const audioBoost = smoothAudioLevel * 2.5;
    const rotSpeed = baseSpeed + audioBoost;
    const rx = time * rotSpeed * 0.7;
    const ry = time * rotSpeed * 1.2;
    const rz = time * rotSpeed * 0.4;

    ctx.save();
    ctx.translate(cx, cy);

    // ============================================================
    // STARK HOLOGRAPHIC SPHERE — 1. SKOŚNE TORBY ORBITALNE (OUTER TILTED ARCS)
    // ============================================================
    const outerR = sphereR * 1.35;
    ctx.save();
    ctx.rotate(time * 0.15);
    ctx.strokeStyle = '#ff6d00';
    ctx.lineWidth = 2 + smoothAudioLevel * 1.5;
    ctx.shadowColor = '#ff9800';
    ctx.shadowBlur = 12 + smoothAudioLevel * 25;
    ctx.globalAlpha = 0.65;

    // Łuki z wycięciami z obrazka Starka
    const numArcs = 4;
    for (let i = 0; i < numArcs; i++) {
        const start = (i / numArcs) * Math.PI * 2 + time * 0.2;
        const end = start + Math.PI * 0.35;
        ctx.beginPath();
        ctx.arc(0, 0, outerR, start, end);
        ctx.stroke();

        // Markery na krawędziach łuków
        const mx = Math.cos(end) * outerR;
        const my = Math.sin(end) * outerR;
        ctx.fillStyle = '#ffe082';
        ctx.fillRect(mx - 3, my - 3, 6, 6);
    }
    ctx.restore();

    // ============================================================
    // STARK HOLOGRAPHIC SPHERE — 2. SIATKA TRÓJWYMIAROWA SFERY (3D SPHERE MESH)
    // ============================================================
    // Generujemy punkty równoleżników (latitudes) i Południków (longitudes)
    const lats = 7;
    const lons = 12;
    const meshAlpha = 0.45 + smoothAudioLevel * 0.45;
    const meshLineWidth = 1.0 + smoothAudioLevel * 1.2;

    ctx.strokeStyle = currentState === 'listening' ? '#ff9800' : '#ffab00';
    ctx.lineWidth = meshLineWidth;
    ctx.shadowColor = '#ff9800';
    ctx.shadowBlur = 15 + smoothAudioLevel * 30;
    ctx.globalAlpha = meshAlpha;

    // Rysowanie równoleżników (Latitude Circles in 3D z falowaniem mowy)
    for (let i = 1; i < lats; i++) {
        const latAngle = (i / lats) * Math.PI - Math.PI / 2; // -PI/2 do PI/2
        const ringRadius = Math.cos(latAngle);
        const yHeight = Math.sin(latAngle);

        const pts = [];
        const steps = 24;
        for (let j = 0; j <= steps; j++) {
            const lonAngle = (j / steps) * Math.PI * 2;
            
            // Falowanie powierzchni kuli przy mówieniu ("kulka żyje mową")
            const waveDistort = smoothAudioLevel * 0.10 * Math.sin(time * 8 + latAngle * 3 + lonAngle * 2);
            const r_mod = ringRadius * (1 + waveDistort);

            const px = Math.cos(lonAngle) * r_mod;
            const py = yHeight * (1 + waveDistort);
            const pz = Math.sin(lonAngle) * r_mod;

            // Obrót 3D
            let p = rotateX([px, py, pz], rx);
            p = rotateY(p, ry);
            p = rotateZ(p, rz);

            pts.push(project(p, sphereR));
        }

        ctx.beginPath();
        for (let k = 0; k < pts.length; k++) {
            if (k === 0) ctx.moveTo(pts[k][0], pts[k][1]);
            else ctx.lineTo(pts[k][0], pts[k][1]);
        }
        ctx.stroke();
    }

    // Rysowanie Południków (Longitude Circles in 3D)
    for (let j = 0; j < lons; j++) {
        const lonAngle = (j / lons) * Math.PI;
        const pts = [];
        const steps = 24;

        for (let i = 0; i <= steps; i++) {
            const latAngle = (i / steps) * Math.PI * 2;
            const waveDistort = smoothAudioLevel * 0.10 * Math.cos(time * 8 + latAngle * 2);
            
            const px = Math.sin(latAngle) * Math.cos(lonAngle) * (1 + waveDistort);
            const py = Math.cos(latAngle) * (1 + waveDistort);
            const pz = Math.sin(latAngle) * Math.sin(lonAngle) * (1 + waveDistort);

            let p = rotateX([px, py, pz], rx);
            p = rotateY(p, ry);
            p = rotateZ(p, rz);

            pts.push(project(p, sphereR));
        }

        ctx.beginPath();
        for (let k = 0; k < pts.length; k++) {
            if (k === 0) ctx.moveTo(pts[k][0], pts[k][1]);
            else ctx.lineTo(pts[k][0], pts[k][1]);
        }
        ctx.stroke();
    }

    // ============================================================
    // STARK HOLOGRAPHIC SPHERE — 3. WIDMO KOREKTORA I FALE MOWY (EQUALIZER & SHOCKWAVES)
    // ============================================================
    if (smoothAudioLevel > 0.02 || currentState === 'speaking') {
        // Fale dźwiękowe rozchodzące się ze sfery (Shockwaves)
        const waveCount = 3;
        for (let w = 0; w < waveCount; w++) {
            const wavePhase = (time * 1.6 + w * 0.33) % 1;
            const waveR = sphereR * (1 + wavePhase * 0.75);
            const waveAlpha = (1 - wavePhase) * (0.35 + smoothAudioLevel * 0.55);
            ctx.strokeStyle = '#ff9800';
            ctx.lineWidth = 1.8;
            ctx.shadowColor = '#ffab00';
            ctx.shadowBlur = 12;
            ctx.globalAlpha = waveAlpha;
            ctx.beginPath();
            ctx.arc(0, 0, waveR, 0, Math.PI * 2);
            ctx.stroke();
        }

        // Kolisty Korektor Widma Mowy wokół sfery
        const eqBars = 32;
        const eqRadius = sphereR * 1.25;
        ctx.save();
        ctx.rotate(time * 0.3);
        for (let i = 0; i < eqBars; i++) {
            const angle = (i / eqBars) * Math.PI * 2;
            const noiseVal = Math.sin(i * 1.8 + time * 14) * 0.5 + 0.5;
            const barHeight = (4 + smoothAudioLevel * 45 * (0.3 + noiseVal * 0.7));
            
            const x1 = Math.cos(angle) * eqRadius;
            const y1 = Math.sin(angle) * eqRadius;
            const x2 = Math.cos(angle) * (eqRadius + barHeight);
            const y2 = Math.sin(angle) * (eqRadius + barHeight);

            ctx.strokeStyle = i % 2 === 0 ? '#ffe082' : '#ff9800';
            ctx.lineWidth = 2.5;
            ctx.shadowColor = '#ffab00';
            ctx.shadowBlur = 10 + smoothAudioLevel * 15;
            ctx.globalAlpha = 0.75 + smoothAudioLevel * 0.25;

            ctx.beginPath();
            ctx.moveTo(x1, y1);
            ctx.lineTo(x2, y2);
            ctx.stroke();
        }
        ctx.restore();
    }

    // ============================================================
    // STARK HOLOGRAPHIC SPHERE — 4. WEWNĘTRZNA WEKTOROWA SFERA
    // ============================================================
    const innerR = sphereR * 0.55;
    ctx.save();
    ctx.rotate(-time * 0.8);
    ctx.strokeStyle = '#ffe082';
    ctx.lineWidth = 1.6 + smoothAudioLevel * 1.5;
    ctx.shadowColor = '#ffab00';
    ctx.shadowBlur = 20 + smoothAudioLevel * 35;
    ctx.globalAlpha = 0.85;

    // Segmentowane wewnętrzne łuki z obrazka
    const innerSegs = 6;
    for (let i = 0; i < innerSegs; i++) {
        const a1 = (i / innerSegs) * Math.PI * 2;
        const a2 = a1 + (Math.PI / innerSegs) * 0.7;
        ctx.beginPath();
        ctx.arc(0, 0, innerR, a1, a2);
        ctx.stroke();
    }
    ctx.restore();

    // ============================================================
    // STARK HOLOGRAPHIC SPHERE — 5. CENTRALNE ZŁOTE JĄDRO (WHITE-GOLD CORE)
    // ============================================================
    const centerR = 8 + smoothAudioLevel * 10;
    const gCore = ctx.createRadialGradient(0, 0, 0, 0, 0, centerR * 2.8);
    gCore.addColorStop(0, 'rgba(255,255,255,1.0)');
    gCore.addColorStop(0.35, 'rgba(255,171,0,0.95)');
    gCore.addColorStop(0.7, 'rgba(255,87,34,0.6)');
    gCore.addColorStop(1, 'rgba(255,152,0,0)');

    ctx.fillStyle = gCore;
    ctx.shadowColor = '#ffab00';
    ctx.shadowBlur = 30 + smoothAudioLevel * 50;
    ctx.beginPath();
    ctx.arc(0, 0, centerR * 2.8, 0, Math.PI * 2);
    ctx.fill();

    // Promienisty biało-złoty punkt centralny
    ctx.fillStyle = '#ffffff';
    ctx.shadowColor = '#ffffff';
    ctx.shadowBlur = 15;
    ctx.beginPath();
    ctx.arc(0, 0, centerR * 0.7, 0, Math.PI * 2);
    ctx.fill();

    ctx.restore();
}

function drawParticles() {
    // Złoto-bursztynowe iskrzące cząsteczki unoszące się wokół sfery Starka
    ctx.save();
    const count = 35 + Math.floor(speakIntensity * 30);
    for (let i = 0; i < count; i++) {
        const seed = i * 137.508;
        const t = (time * 0.35 + seed) % 20;
        const angle = seed + time * (0.08 + (i % 4) * 0.04);
        const dist = R * (0.35 + 0.9 * (t / 20));
        const alpha = Math.sin((t / 20) * Math.PI) * (0.3 + smoothAudioLevel * 0.6);
        const pSize = 1.2 + (i % 3) * 0.8 + smoothAudioLevel * 1.5;

        const px = cx + Math.cos(angle) * dist;
        const py = cy + Math.sin(angle) * dist;

        ctx.fillStyle = i % 2 === 0 ? '#ffe082' : '#ff9800';
        ctx.shadowColor = '#ffab00';
        ctx.shadowBlur = 8 + smoothAudioLevel * 12;
        ctx.globalAlpha = alpha;
        ctx.beginPath();
        ctx.arc(px, py, pSize, 0, Math.PI * 2);
        ctx.fill();
    }
    ctx.restore();
}

// ============================================================
// ANIMATION LOOP
// ============================================================

function animate() {
    const dt = 0.016;
    time += dt;

    // Smooth intensity transition
    const targetIntensity = currentState === 'speaking' ? 1 :
                            currentState === 'listening' ? 0.3 : 0;
    speakIntensity += (targetIntensity - speakIntensity) * 0.08;

    // Wygładzanie poziomu audio (szybkie narastanie, wolniejsze opadanie)
    const audioSmoothing = smoothAudioLevel < audioLevel ? 0.25 : 0.08;
    smoothAudioLevel += (audioLevel - smoothAudioLevel) * audioSmoothing;

    // Faza oddychania w trybie listening
    if (currentState === 'listening') {
        listenBreath += dt * 1.8;  // wolne oddychanie
    } else {
        listenBreath *= 0.95;  // stopniowe wygaszanie
    }

    // Automatyczne opadanie audioLevel (jeśli Python nie wysyła aktualizacji)
    audioLevel *= 0.92;

    // Clear & draw
    ctx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    drawBackground();
    drawCentralGlow();
    drawParticles();

    // Rysuj pierścienie od zewnętrznych do wewnętrznych
    for (const ring of rings) {
        drawRing(ring);
    }

    drawCore();

    requestAnimationFrame(animate);
}

// ============================================================
// STATE MANAGEMENT (called from Python via evaluate_js)
// ============================================================

// Wywoływana z Pythona — ustawia poziom głośności audio w czasie rzeczywistym
function setAudioLevel(level) {
    audioLevel = Math.max(0, Math.min(1, level));
}

// Wywoływana z Pythona — przekazuje aktualnie wypowiadany tekst mowy
function setSpokenText(text) {
    const box = document.getElementById('speech-box');
    const textEl = document.getElementById('speech-text');

    if (text && text.trim().length > 0) {
        textEl.textContent = text;
        box.classList.remove('speech-hidden');
    } else {
        box.classList.add('speech-hidden');
    }
}

function setState(newState) {
    currentState = newState;
    // Resetuj audio level przy zmianie stanu (żeby rdzeń nie zawisnął w pozycji)
    if (newState !== 'speaking') audioLevel = 0;
    document.body.setAttribute('data-state', newState);
    const stateText = document.getElementById('state-text');
    const statusText = document.getElementById('status-text');
    switch (newState) {
        case 'idle':
            stateText.textContent = 'STANDBY';
            statusText.textContent = 'OPERATIONAL';
            break;
        case 'listening':
            stateText.textContent = 'LISTENING';
            statusText.textContent = 'LISTENING';
            break;
        case 'speaking':
            stateText.textContent = 'SPEAKING';
            statusText.textContent = 'ACTIVE';
            break;
    }
}

// ============================================================
// LOG MANAGEMENT
// ============================================================

function addLog(message, type = 'info') {
    const now = new Date();
    const timeStr = now.toLocaleTimeString('pl-PL', { hour12: false });
    logs.push({ text: message, type, time: timeStr });
    if (logs.length > 15) logs.shift();

    const panel = document.getElementById('log-panel');
    panel.innerHTML = '';
    for (const log of logs) {
        const div = document.createElement('div');
        div.className = `line log-entry ${log.type}`;
        if (log.type === 'cmd') div.className = 'line log-entry cmd';
        if (log.type === 'warning') div.className = 'line log-entry warning';
        if (log.type === 'success') div.className = 'line log-entry success';
        div.textContent = `[${log.time}] ${log.text}`;
        panel.appendChild(div);
    }
    // Auto-scroll to bottom
    panel.scrollTop = panel.scrollHeight;
}

// ============================================================
// STATS UPDATE (called from Python)
// ============================================================

function updateStats(data) {
    stats = data;

    // System panel
    if (data.system) {
        const s = data.system;
        document.getElementById('stats-system').innerHTML = `
            <div class="line">CPU: ${s.cpu}%</div>
            <div class="line">RAM: ${s.ram_used} / ${s.ram_total} GB (${s.ram_percent}%)</div>
            <div class="line">DISK C: ${s.disk_free} GB free</div>
            ${s.battery !== null ? `<div class="line">BATTERY: ${s.battery}% ${s.charging ? '⚡ CHARGING' : ''}</div>` : ''}
            <div class="line">UPTIME: ${s.uptime}</div>
        `;
    }

    // Network panel
    if (data.network) {
        const n = data.network;
        document.getElementById('stats-network').innerHTML = `
            <div class="line">LOCAL IP: ${n.local_ip}</div>
            <div class="line">PUBLIC IP: ${n.public_ip}</div>
            <div class="line">SENT: ${n.sent} MB</div>
            <div class="line">RECV: ${n.recv} MB</div>
        `;
    }

    // Processes panel
    if (data.processes) {
        let html = '';
        for (const p of data.processes) {
            html += `<div class="line">${p.name}  CPU:${p.cpu}%  RAM:${p.ram}%</div>`;
        }
        document.getElementById('stats-processes').innerHTML = html || '<div class="line dim">No notable processes</div>';
    }
}

// ============================================================
// CLOCK
// ============================================================

function updateClock() {
    const now = new Date();
    document.getElementById('clock').textContent =
        now.toLocaleTimeString('pl-PL', { hour12: false });
}
setInterval(updateClock, 1000);
updateClock();

// ============================================================
// INIT
// ============================================================

setState('idle');
addLog('System JARVIS inicjalizowany', 'success');
addLog('Oczekiwanie na backend...', 'info');
animate();
