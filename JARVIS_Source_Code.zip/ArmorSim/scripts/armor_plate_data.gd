class_name ArmorPlateData
extends Resource

enum ArmorMaterial { RHA, FHA, CAST, HIGH_HARDNESS, STRUCTURAL_STEEL, ALUMINIUM, CERAMIC, ARAMID }

@export var thickness_mm: float = 100.0
@export var angle_deg: float = 0.0
@export var material: ArmorMaterial = ArmorMaterial.RHA

static func get_material_name(mat: ArmorMaterial) -> String:
	match mat:
		ArmorMaterial.RHA: return "RHA (stal walcowana)"
		ArmorMaterial.FHA: return "FHA (utwardzana)"
		ArmorMaterial.CAST: return "Stal odlewana"
		ArmorMaterial.HIGH_HARDNESS: return "Stal twarda"
		ArmorMaterial.STRUCTURAL_STEEL: return "Stal konstrukcyjna"
		ArmorMaterial.ALUMINIUM: return "Aluminium"
		ArmorMaterial.CERAMIC: return "Ceramika"
		ArmorMaterial.ARAMID: return "Aramid/Kevlar"
		_: return "Nieznany"

static func get_ke_multiplier(mat: ArmorMaterial, thickness: float = 100.0) -> float:
	match mat:
		ArmorMaterial.RHA: return 1.0
		ArmorMaterial.FHA: return 1.2 if thickness < 100.0 else 0.9
		ArmorMaterial.CAST: return 0.9
		ArmorMaterial.HIGH_HARDNESS: return 1.15
		ArmorMaterial.STRUCTURAL_STEEL: return 0.45
		ArmorMaterial.ALUMINIUM: return 0.33
		ArmorMaterial.CERAMIC: return 1.8
		ArmorMaterial.ARAMID: return 0.2
		_: return 1.0

static func get_ce_multiplier(mat: ArmorMaterial) -> float:
	match mat:
		ArmorMaterial.RHA: return 1.0
		ArmorMaterial.FHA: return 1.0
		ArmorMaterial.CAST: return 0.9
		ArmorMaterial.HIGH_HARDNESS: return 1.0
		ArmorMaterial.STRUCTURAL_STEEL: return 0.45
		ArmorMaterial.ALUMINIUM: return 0.40
		ArmorMaterial.CERAMIC: return 2.5
		ArmorMaterial.ARAMID: return 1.5
		_: return 1.0
