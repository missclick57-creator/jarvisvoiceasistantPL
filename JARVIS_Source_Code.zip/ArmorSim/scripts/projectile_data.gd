class_name ProjectileData
extends Resource

enum Nation { USA, USSR, GERMANY }
enum ShellType { AP, APCBC, APCR, APFSDS, HEAT, TANDEM_HEAT, ATGM, HE }

@export var name: String = ""
@export var nation: Nation = Nation.USA
@export var shell_type: ShellType = ShellType.AP
@export var caliber_mm: float = 0.0
@export var mass_kg: float = 0.0
@export var velocity_mps: float = 0.0
@export var de_marre_constant: float = 0.05
@export var penetrator_length_mm: float = 0.0
@export var penetrator_density: float = 0.0
@export var heat_penetration_mm: float = 0.0
@export var tandem_precursor_mm: float = 0.0
@export var is_top_attack: bool = false
@export var normalization_deg: float = 0.0
@export var ricochet_angle_deg: float = 70.0
@export var description: String = ""

func get_shell_type_name() -> String:
	match shell_type:
		ShellType.AP: return "AP"
		ShellType.APCBC: return "APCBC"
		ShellType.APCR: return "APCR"
		ShellType.APFSDS: return "APFSDS"
		ShellType.HEAT: return "HEAT"
		ShellType.TANDEM_HEAT: return "Tandem HEAT"
		ShellType.ATGM: return "ATGM"
		ShellType.HE: return "HE"
		_: return "Nieznany"

func get_nation_name() -> String:
	match nation:
		Nation.USA: return "USA"
		Nation.USSR: return "ZSRR/Rosja"
		Nation.GERMANY: return "Niemcy"
		_: return "?"

func is_kinetic() -> bool:
	return shell_type in [ShellType.AP, ShellType.APCBC, ShellType.APCR, ShellType.APFSDS]

func is_chemical() -> bool:
	return shell_type in [ShellType.HEAT, ShellType.TANDEM_HEAT, ShellType.ATGM]
