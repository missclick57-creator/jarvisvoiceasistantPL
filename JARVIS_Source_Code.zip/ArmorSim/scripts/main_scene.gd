extends Control
class_name MainSceneController

## Kontroler glownej sceny ArmorSim.
## Trzy proste kroki: 1. Zbuduj pancerz  2. Wybierz pocisk  3. OGNIA!

# --- Referencje UI ---
@onready var thickness_slider: HSlider = %ThicknessSlider
@onready var thickness_value: Label = %ThicknessValue
@onready var angle_slider: HSlider = %AngleSlider
@onready var angle_value: Label = %AngleValue
@onready var material_option: OptionButton = %MaterialOption
@onready var add_plate_btn: Button = %AddPlateButton
@onready var addon_option: OptionButton = %AddonOption
@onready var add_addon_btn: Button = %AddAddonButton
@onready var clear_btn: Button = %ClearButton
@onready var nation_option: OptionButton = %NationOption
@onready var ammo_list: ItemList = %AmmoList
@onready var projectile_info: RichTextLabel = %ProjectileInfo
@onready var fire_btn: Button = %FireButton
@onready var result_log: RichTextLabel = %ResultLog
@onready var armor_visualizer: ArmorVisualizer = %ArmorVisualizer
@onready var shot_animator: ShotAnimator = %ShotAnimator
@onready var armor_layer_list: VBoxContainer = %ArmorLayerList
@onready var status_label: Label = %StatusLabel
@onready var no_armor_label: Label = %NoArmorLabel

# Presety
@onready var preset_tiger: Button = %PresetTiger
@onready var preset_t34: Button = %PresetT34
@onready var preset_abrams: Button = %PresetAbrams
@onready var preset_t90: Button = %PresetT90
@onready var preset_leo2: Button = %PresetLeo2
@onready var preset_pt91: Button = %PresetPT91

# --- Stan ---
var armor_stack: ArmorStack = ArmorStack.new()
var all_projectiles: Array[ProjectileData] = []
var filtered_projectiles: Array[ProjectileData] = []
var selected_projectile: ProjectileData = null


func _ready() -> void:
	# Baza amunicji
	all_projectiles = AmmoDatabase.get_all_projectiles()
	
	# Materialy pancerza
	for mat_val in ArmorPlateData.ArmorMaterial.values():
		material_option.add_item(ArmorPlateData.get_material_name(mat_val), mat_val)
	
	# Pancerze dodatkowe
	addon_option.add_item("Kontakt-1 (ERA, vs HEAT)", 0)
	addon_option.add_item("Kontakt-5 (ERA, vs HEAT+KE)", 1)
	addon_option.add_item("Relikt (ERA, najnowszy)", 2)
	addon_option.add_item("Blazer (ERA, Izrael)", 3)
	addon_option.add_item("ERAWA-2 (ERA, Polska)", 4)
	addon_option.add_item("NERA (reaktywny niewybuchowy)", 5)
	addon_option.add_item("Chobham (kompozyt)", 6)
	addon_option.add_item("Pancerz kratkowy (Slat)", 7)
	addon_option.add_item("Pancerz przestrzenny (100mm)", 8)
	
	# Nacje
	nation_option.add_item("Wszystkie nacje", 0)
	nation_option.add_item("USA", 1)
	nation_option.add_item("ZSRR / Rosja", 2)
	nation_option.add_item("Niemcy", 3)
	
	# Sygnaly - slidery
	thickness_slider.value_changed.connect(_on_thickness_changed)
	angle_slider.value_changed.connect(_on_angle_changed)
	
	# Sygnaly - przyciski
	add_plate_btn.pressed.connect(_on_add_plate)
	add_addon_btn.pressed.connect(_on_add_addon)
	clear_btn.pressed.connect(_on_clear)
	
	# Sygnaly - amunicja
	nation_option.item_selected.connect(_on_nation_changed)
	ammo_list.item_selected.connect(_on_ammo_selected)
	fire_btn.pressed.connect(_on_fire)
	
	# Sygnaly - presety
	preset_tiger.pressed.connect(_load_preset_tiger)
	preset_t34.pressed.connect(_load_preset_t34)
	preset_abrams.pressed.connect(_load_preset_abrams)
	preset_t90.pressed.connect(_load_preset_t90)
	preset_leo2.pressed.connect(_load_preset_leo2)
	preset_pt91.pressed.connect(_load_preset_pt91)
	
	# Domyslny preset
	_load_preset_tiger()
	_update_ammo_list()
	
	status_label.text = "Gotowy - kliknij preset lub zbuduj pancerz, wybierz pocisk i strzelaj!"


# ==========================================
# PRESETY CZOLGOW
# ==========================================

func _load_preset_tiger() -> void:
	armor_stack.clear()
	var plate := ArmorPlateData.new()
	plate.thickness_mm = 100.0
	plate.angle_deg = 10.0
	plate.material = ArmorPlateData.ArmorMaterial.RHA
	armor_stack.add_plate(plate)
	_after_preset("Tiger I - przod kadluba (100mm RHA @ 10 st.)")

func _load_preset_t34() -> void:
	armor_stack.clear()
	var plate := ArmorPlateData.new()
	plate.thickness_mm = 45.0
	plate.angle_deg = 60.0
	plate.material = ArmorPlateData.ArmorMaterial.RHA
	armor_stack.add_plate(plate)
	_after_preset("T-34 - przod kadluba (45mm RHA @ 60 st.)")

func _load_preset_abrams() -> void:
	armor_stack.clear()
	armor_stack.add_addon(AddonArmorData.create_composite_chobham())
	var plate := ArmorPlateData.new()
	plate.thickness_mm = 200.0
	plate.angle_deg = 15.0
	plate.material = ArmorPlateData.ArmorMaterial.RHA
	armor_stack.add_plate(plate)
	var inner := ArmorPlateData.new()
	inner.thickness_mm = 50.0
	inner.angle_deg = 0.0
	inner.material = ArmorPlateData.ArmorMaterial.RHA
	armor_stack.add_plate(inner)
	_after_preset("M1A2 Abrams - Chobham + 200mm RHA + 50mm tyl")

func _load_preset_t90() -> void:
	armor_stack.clear()
	armor_stack.add_addon(AddonArmorData.create_relikt())
	var composite := ArmorPlateData.new()
	composite.thickness_mm = 150.0
	composite.angle_deg = 20.0
	composite.material = ArmorPlateData.ArmorMaterial.CERAMIC
	armor_stack.add_plate(composite)
	var plate := ArmorPlateData.new()
	plate.thickness_mm = 100.0
	plate.angle_deg = 20.0
	plate.material = ArmorPlateData.ArmorMaterial.RHA
	armor_stack.add_plate(plate)
	_after_preset("T-90M - Relikt ERA + 150mm ceramika + 100mm RHA")

func _load_preset_leo2() -> void:
	armor_stack.clear()
	armor_stack.add_addon(AddonArmorData.create_composite_chobham())
	var plate := ArmorPlateData.new()
	plate.thickness_mm = 180.0
	plate.angle_deg = 20.0
	plate.material = ArmorPlateData.ArmorMaterial.RHA
	armor_stack.add_plate(plate)
	var inner := ArmorPlateData.new()
	inner.thickness_mm = 40.0
	inner.angle_deg = 0.0
	inner.material = ArmorPlateData.ArmorMaterial.RHA
	armor_stack.add_plate(inner)
	_after_preset("Leopard 2A6 - Chobham + 180mm RHA + 40mm tyl")

func _load_preset_pt91() -> void:
	armor_stack.clear()
	armor_stack.add_addon(AddonArmorData.create_erawa_2())
	var plate := ArmorPlateData.new()
	plate.thickness_mm = 200.0
	plate.angle_deg = 25.0
	plate.material = ArmorPlateData.ArmorMaterial.CAST
	armor_stack.add_plate(plate)
	_after_preset("PT-91 Twardy - ERAWA-2 ERA + 200mm odlew @ 25 st.")

func _after_preset(desc: String) -> void:
	_update_armor_list()
	_update_visualizer()
	armor_visualizer.clear_hit()
	result_log.clear()
	status_label.text = "Zaladowano: " + desc


# ==========================================
# HANDLERY SYGNALOW
# ==========================================

func _on_thickness_changed(value: float) -> void:
	thickness_value.text = str(int(value)) + "mm"

func _on_angle_changed(value: float) -> void:
	angle_value.text = str(int(value)) + " st."

func _on_add_plate() -> void:
	var plate := ArmorPlateData.new()
	plate.thickness_mm = thickness_slider.value
	plate.angle_deg = angle_slider.value
	plate.material = material_option.get_selected_id() as ArmorPlateData.ArmorMaterial
	armor_stack.add_plate(plate)
	_update_armor_list()
	_update_visualizer()
	status_label.text = "Dodano plyte: " + str(int(plate.thickness_mm)) + "mm " + ArmorPlateData.get_material_name(plate.material) + " @ " + str(int(plate.angle_deg)) + " st."

func _on_add_addon() -> void:
	var addon: AddonArmorData = _create_addon(addon_option.get_selected_id())
	if addon:
		armor_stack.add_addon(addon)
		_update_armor_list()
		_update_visualizer()
		status_label.text = "Dodano: " + addon.name

func _on_clear() -> void:
	armor_stack.clear()
	_update_armor_list()
	_update_visualizer()
	armor_visualizer.clear_hit()
	result_log.clear()
	status_label.text = "Pancerz wyczyszczony."

func _on_nation_changed(_index: int) -> void:
	_update_ammo_list()

func _on_ammo_selected(index: int) -> void:
	if index >= 0 and index < filtered_projectiles.size():
		selected_projectile = filtered_projectiles[index]
		_update_projectile_info()
		status_label.text = "Wybrano: " + selected_projectile.name + " - kliknij OGNIA!"

func _on_fire() -> void:
	if armor_stack.get_layer_count() == 0:
		status_label.text = "BLAD: Najpierw dodaj pancerz! (Krok 1)"
		return
	if not selected_projectile:
		status_label.text = "BLAD: Najpierw wybierz pocisk! (Krok 2)"
		return
	
	var result: HitResult = BallisticsSolver.solve_hit(selected_projectile, armor_stack)
	
	var log_text: String = "\n[b]=== " + selected_projectile.name + " ===[/b]\n"
	for entry in result.log_entries:
		log_text += "  > " + entry + "\n"
	
	if result.ricocheted:
		log_text += "[color=yellow][b]>> RYKOSZET <<[/b][/color]\n"
	elif result.penetrated:
		log_text += "[color=lime][b]>> PRZEBICIE << Resztkowa: " + str(snapped(result.residual_penetration_mm, 0.1)) + "mm[/b][/color]\n"
	else:
		log_text += "[color=red][b]>> ZATRZYMANIE <<[/b][/color]\n"
	
	result_log.append_text(log_text)
	
	# Scroll do dolu
	await get_tree().process_frame
	var scrollbar = result_log.get_v_scroll_bar()
	if scrollbar:
		scrollbar.value = scrollbar.max_value
	
	armor_visualizer.set_hit_result(result)
	
	var from_pos := Vector2(0, armor_visualizer.size.y / 2.0)
	var to_pos := Vector2(200, armor_visualizer.size.y / 2.0)
	shot_animator.start_animation(from_pos, to_pos, result, selected_projectile.shell_type)
	
	status_label.text = selected_projectile.name + " -> " + result.get_outcome_text()


# ==========================================
# AKTUALIZACJA UI
# ==========================================

func _update_ammo_list() -> void:
	ammo_list.clear()
	filtered_projectiles.clear()
	var nation_idx: int = nation_option.selected
	
	for proj in all_projectiles:
		var should_add: bool = (nation_idx == 0) or (proj.nation == nation_idx - 1)
		if should_add:
			filtered_projectiles.append(proj)
			var prefix: String = ""
			match proj.nation:
				ProjectileData.Nation.USA: prefix = "[USA] "
				ProjectileData.Nation.USSR: prefix = "[ZSRR] "
				ProjectileData.Nation.GERMANY: prefix = "[DE] "
			ammo_list.add_item(prefix + proj.name)

func _update_armor_list() -> void:
	for child in armor_layer_list.get_children():
		child.queue_free()
	
	no_armor_label.visible = (armor_stack.get_layer_count() == 0)
	
	for i in range(armor_stack.get_layer_count()):
		var layer: Dictionary = armor_stack.get_layer(i)
		var hbox := HBoxContainer.new()
		hbox.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		
		var label := Label.new()
		label.size_flags_horizontal = Control.SIZE_EXPAND_FILL
		
		if layer.type == "plate":
			var plate: ArmorPlateData = layer.data
			label.text = "[Plyta] " + str(int(plate.thickness_mm)) + "mm " + ArmorPlateData.get_material_name(plate.material) + " @ " + str(int(plate.angle_deg)) + " st."
		elif layer.type == "addon":
			var addon: AddonArmorData = layer.data
			label.text = "[Dodatek] " + addon.name
		
		var remove_btn := Button.new()
		remove_btn.text = "X"
		remove_btn.custom_minimum_size = Vector2(28, 28)
		var idx: int = i
		remove_btn.pressed.connect(func(): _remove_layer(idx))
		
		hbox.add_child(label)
		hbox.add_child(remove_btn)
		armor_layer_list.add_child(hbox)

func _remove_layer(index: int) -> void:
	armor_stack.remove_layer(index)
	_update_armor_list()
	_update_visualizer()
	status_label.text = "Usunieto warstwe."

func _update_visualizer() -> void:
	armor_visualizer.set_armor_stack(armor_stack)

func _update_projectile_info() -> void:
	if not selected_projectile:
		projectile_info.clear()
		projectile_info.append_text("Wybierz pocisk z listy powyzej")
		return
	
	var base_pen: float = BallisticsSolver._calculate_initial_penetration(selected_projectile)
	
	var bbcode: String = ""
	bbcode += "[b]" + selected_projectile.name + "[/b]\n"
	bbcode += "Typ: " + selected_projectile.get_shell_type_name() + "\n"
	bbcode += "Kaliber: " + str(int(selected_projectile.caliber_mm)) + "mm\n"
	
	if selected_projectile.is_kinetic():
		bbcode += "Masa: " + str(snapped(selected_projectile.mass_kg, 0.1)) + "kg\n"
		bbcode += "Predkosc: " + str(int(selected_projectile.velocity_mps)) + " m/s\n"
	elif selected_projectile.shell_type == ProjectileData.ShellType.APFSDS:
		bbcode += "Penetrator: " + str(int(selected_projectile.penetrator_length_mm)) + "mm\n"
		bbcode += "Predkosc: " + str(int(selected_projectile.velocity_mps)) + " m/s\n"
	else:
		bbcode += "Predkosc: " + str(int(selected_projectile.velocity_mps)) + " m/s\n"
	
	bbcode += "[color=orange][b]Penetracja: ~" + str(int(base_pen)) + "mm RHA[/b][/color]\n"
	bbcode += "[i]" + selected_projectile.description + "[/i]"
	
	projectile_info.clear()
	projectile_info.append_text(bbcode)

func _create_addon(index: int) -> AddonArmorData:
	match index:
		0: return AddonArmorData.create_kontakt_1()
		1: return AddonArmorData.create_kontakt_5()
		2: return AddonArmorData.create_relikt()
		3: return AddonArmorData.create_blazer()
		4: return AddonArmorData.create_erawa_2()
		5: return AddonArmorData.create_nera()
		6: return AddonArmorData.create_composite_chobham()
		7: return AddonArmorData.create_slat()
		8: return AddonArmorData.create_spaced(100.0)
		_: return null
